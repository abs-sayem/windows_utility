1. Open cmd as Administrator and go to the Office2024 Directory and Run the following any one:

2. Run the Following any one Command:

> For All Office-365 Products:
	> './setup.exe /configure Configuration-Office365-x64.xml'

> For Word Excel and PowerPoint:
	> './setup.exe /configure Configuration-Office2024WEP.xml'

> For Project Only:
	> './setup.exe /configure Configuration-Office2024Project.xml'

> For Word, Excel, PowerPoint and Project:
	> './setup.exe /configure Configuration-Office2024WEPP.xml'

> For Word, Excel, PowerPoint and Visio:
	> './setup.exe /configure Configuration-Office2024WEPV.xml'

> For Word, Excel, PowerPoint, Project and Visio:
	> './setup.exe /configure Configuration-Office2024WEPPV.xml'