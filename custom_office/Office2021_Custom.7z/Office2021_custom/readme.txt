> open cmd in this directory
> paste ".\setup.exe /configure .\configuration-Office2021Enterprise.xml"
> press Enter